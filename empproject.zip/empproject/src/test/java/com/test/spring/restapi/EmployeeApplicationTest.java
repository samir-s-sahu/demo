package com.test.spring.restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeApplicationTest {

	@Test
	void contextLoads() {
	}

}